package bgu.spl.net.api.Messages;

import bgu.spl.net.api.MessageImpl;

public class Logout extends MessageImpl {
    public Logout() {super ((short) 3);}
}
