package bgu.spl.net.api.Messages;

import bgu.spl.net.api.MessageImpl;

public class Logstat extends MessageImpl {
    public Logstat() {super((short) 7);}
}
